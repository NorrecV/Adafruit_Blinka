"""Boards definition from Pine64"""

# SPDX-FileCopyrightText: 2021 Melissa LeBlanc-Williams for Adafruit Industries
#
# SPDX-License-Identifier: MIT
"""Pin definitions for the RockPro64."""

from adafruit_blinka.microcontroller.rockchip.rk3399 import pin

#note pin id are order as they appear on PIbus from phyisical pin 1
D2 = pin.GPIO1_C4 #physical pin 3
D3 = pin.GPIO1_C5 #physical pin 5
D4 = pin.GPIO4_D0 #physical pin 7
D14 = pin.GPIO4_C4 #physical pin 8
D15 = pin.GPIO4_C3 #physical pin 10
D17 = pin.GPIO1_C6 #physical pin 11
D18 = pin.GPIO3_D0 #physical pin 12
D27 = pin.GPIO1_C2 #physical pin 13
D22 = pin.GPIO1_A1 #physical pin 15
D23 = pin.GPIO1_A4 #physical pin 16
D24 = pin.GPIO4_C5 #physical pin 18
D10 = pin.GPIO1_B0 #physical pin 19
D9 = pin.GPIO1_A7 #physical pin 21
D25 = pin.GPIO4_D1 #physical pin 22
D11 = pin.GPIO1_B1 #physical pin 23
D8 = pin.GPIO1_B2 #physical pin 24
D7 = pin.GPIO1_B5 #physical pin 26; see RK3399 pin.py for current issue
D0 = pin.GPIO1_B3 #physical pin 27
D1 = pin.GPIO1_B4 #physical pin 28
D5 = pin.GPIO4_D3 #phyiscal pin 29
D6 = pin.GPIO4_D4 
D12 = pin.GPIO3_D4
D13 = pin.GPIO3_D5
D19 = pin.GPIO3_D2
D16 = pin.GPIO3_D6
D26 = pin.GPIO3_D1
D20 = pin.GPIO3_D3
D21 = pin.GPIO3_D7 #physical pin 40

SDA = D2
SCL = D3

SCL2 = D0
SDA2 = D1

SCLK = 0
MOSI = 0
MISO = 0
CS = 0
SCK = SCLK

UART_TX = 0
UART_RX = 0

UART3_TX = 0
UART3_RX = 0

UART4_TX = 0
UART4_RX = 0
